DOI - https://doi.org/10.5281/zenodo.17955246


Important note: our automatically generated report in .tex format is saved under path "data/report/experiment_report.tex". It is exported to the PDF under the name "BI_Assignment3_Report_008_Automatic.pdf". However, because format was not satisfactory, we made some improvements and corrections. The corrected version of report is saved under name "BI_Assignment3_Report_008_Corrected.pdf"


GitHub repository - https://github.com/milialeksic/BI_ass3

